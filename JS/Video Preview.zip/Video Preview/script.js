

function overVideo(vid) {
    vid.play();
    
}

 function leaveVideo(vid) {
    vid.pause();
     
}