

// with "Like" ++


 

  function any(ml){
    document.getElementById(ml).innerText ++;
  }

  function fat(elm){
    document.getElementById(elm).innerText ++;
  }
  function fow(elmm){
    document.getElementById(elmm).innerText ++;
  } 

// with "remove the element"
  function don(element){
   element.remove()
  }
  
  // for alert the element
  function choice1(){
    var x =document.getElementById("test-dropdown");
    alert(x.options[x.selectedIndex].value);
  }

