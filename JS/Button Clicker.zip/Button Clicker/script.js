function btn(element){
    element.innerText="Logout"
}
function rmv(element){
    element.remove()
}
function aler(){
    alert("ninja was liked")
}